"use strict"

CKEDITOR.plugins.setLang( 'btgrid', 'nl', {
	selNumCols: 'Kies het aantal kolommen',
  genNrRows: 'Aantal rijen te genereren',
	infoTab: 'Info',
	createBtGrid: 'Maak een Bootstrap grid',
	editBtGrid: 'Bewerk de Bootstrap grid',
	numColsError:  'Kies een aantal kolommen',
	numRowsError: 'Kies een aantal rijen',
} );
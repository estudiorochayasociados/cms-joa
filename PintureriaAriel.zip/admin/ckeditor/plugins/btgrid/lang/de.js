"use strict"

CKEDITOR.plugins.setLang( 'btgrid', 'de', {
	selNumCols: 'Anzahl der Spalten',
	genNrRows: 'Anzahl der zu generierenden Zeilen',
	infoTab: 'Info',
	createBtGrid: 'Ein Bootstrap Grid erstellen',
	editBtGrid: 'Bootstrap Grid editieren',
	numColsError:  unescape('Bitte die Anzahl der Spalten w%E4hlen.'),
	numRowsError: unescape('Bitte nur Zahlenwerte f%FCr die Anzahl der Spalten w%E4hlen.'),
} );

<?php

$imagebrowser1 = "Buscador de imágenes";
$imagebrowser2 = "Total:";
$imagebrowser3 = "Imagenes";
$imagebrowser4 = "Arrastrar tu imagen aquí";

$uploadpanel1 = "Seleccionar el archivo a subir:";
$uploadpanel2 = "Imagen se deberá subir:";
$uploadpanel3 = " ";

$panelsettings1 = "Se subirá en:";
$panelsettings2 = "Elegir una carpeta existente:";
$panelsettings3 = "Historial:";
$panelsettings4 = "Ajustes:";
$panelsettings5 = "Ocultar extensión";
$panelsettings6 = "Mostrar extensón";
$panelsettings7 = "Contraseña:";
$panelsettings8 = "Salir";
$panelsettings9 = "Deshabilitar contraseña";
$panelsettings10 = " ";
$panelsettings11 = " ";
$panelsettings12 = " ";
$panelsettings13 = " ";
$panelsettings14 = " ";
$panelsettings15 = " ";
$panelsettings16 = " ";
$panelsettings17 = " ";
$panelsettings18 = " ";
$panelsettings19 = " ";
$panelsettings20 = "Cambiar lenguaje";
$panelsettings21 = " ";
$panelsettings22 = " ";

$newssection1 = " ";

$buttons1 = "Ver";
$buttons2 = "Descargar";
$buttons3 = "Usar";
$buttons4 = "Borrar";
$buttons5 = "Cancelar";
$buttons6 = "Guardar";
$buttons7 = "Subir imágenes";

$alerts1 = " ";
$alerts2 = " ";
$alerts3 = " ";
$alerts4 = " ";
$alerts5 = " ";
$alerts6 = " ";
$alerts7 = " ";
$alerts8 = " ";
$alerts9 = "La carpeta";
$alerts10 = "no encontrado";
$alerts11 = "crear carpeta";

$dltimageerrors1 = "Error.";
$dltimageerrors2 = "Solo se pueden subir imágenes";
$dltimageerrors3 = "La imagen que quieres eliminar no está en la carpeta";
$dltimageerrors4 = "No podemos borrar la imagen. Por favor elegir otra imagen.";
$dltimageerrors5 = "Esta selección no se puede eliminar.";
$dltimageerrors6 = "El archivo no existe";

$uploadimgerrors1 = "El archivo no es una imagen";
$uploadimgerrors2 = "El archivo ya existe";
$uploadimgerrors3 = "El archivo es muy pesado";
$uploadimgerrors4 = "Solos se sube JPG, JPEG, PNG & GIF.";
$uploadimgerrors5 = " ";
$uploadimgerrors6 = " ";
$uploadimgerrors7 = " ";

$loginerrors1 = "Usuario incorrecto";

$configerrors1 = "Visibilidad";
$configerrors2 = "Visibilidad";

$loginsite1 = "Bienvenido!";
$loginsite2 = "Ingresar";
$loginsite3 = "usuario";
$loginsite4 = "contraseña";
$loginsite5 = "Ingresar";

$createaccount1 = "Crear cuenta";
$createaccount2 = "Deshabilitar login";
$createaccount3 = " ";

$langpanel1 = "Seleccionar lenguaje";
$langpanel2 = "Seleccionado";
$langpanel3 = "Cerrar";
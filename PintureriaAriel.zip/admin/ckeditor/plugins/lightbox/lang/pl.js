﻿
CKEDITOR.plugins.setLang( 'lightbox', 'pl', {
    label: 'Wstaw/edytuj galerię Lightbox',
	url: 'Obraz do wyświetlenia w oknie Lightbox',
    preview: 'Podgląd',
    title: 'Tytuł obrazu',
    gallery: 'Nazwa grupy obrazów (galerii)'
} );
